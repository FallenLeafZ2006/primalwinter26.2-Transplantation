# Primal Winter 26.2 · 天气循环改版（三天雪两天晴）

这是移植版（`primal-winter-26.2`）的**第二个独立改版**：把「永久暴雪」换成**按天排布的天气表**。

原版移植保持原模组行为（一直下雪），本目录与 `D:\qq下载\PrimalWinter-26.2-间歇降雪`（按秒切换的版本）都**不覆盖任何已安装的模组**。

---

## 1. 效果

天气按**游戏内天数**排布，一天一个状态，循环播放。默认是 5 天一轮：

| 天数 | 状态 | 表现 |
|---|---|---|
| 第 1 天 | `light_snow` 小雪 | 下雪、不打雷；雪柱半径 55%、粒子约 40% |
| 第 2 天 | `heavy_snow` 大雪 | 下雪 + 雷暴；天空更暗、雪最密（100%） |
| 第 3 天 | `light_snow` 小雪 | 同第 1 天 |
| 第 4 天 | `clear` 晴 | 不下雪、不生成新积雪层 |
| 第 5 天 | `clear` 晴 | 同上 |

→ 正好是「三天雪、两天晴」，然后从第 1 天重新开始。

## 2. 配置（`config/primalwinter.toml` 的 `[general]` 段）

```toml
# 关闭后恢复原模组行为：永久暴雪
enableSnowCycle = true

# 一天一个状态，无限循环。允许值：light_snow / heavy_snow / clear
snowCyclePattern = ["light_snow", "heavy_snow", "light_snow", "clear", "clear"]
```

想改节奏直接改这个列表，比如：
- 只要「一天雪一天晴」：`["heavy_snow", "clear"]`
- 五天里下四天：`["heavy_snow", "light_snow", "heavy_snow", "light_snow", "clear"]`
- 想恢复永久暴雪：`enableSnowCycle = false`

> 一天 = 24000 游戏刻 = 现实 20 分钟（20 TPS 时）。

## 3. 实测验证

用 RCON 逐天推进（`time add 24000`），日志严格按表执行：

```
[21:31:32] Winter weather: day 0 -> light_snow (pattern position 1 of 5)
[21:31:33] Winter weather: day 1 -> heavy_snow (pattern position 2 of 5)
[21:31:35] Winter weather: day 2 -> light_snow (pattern position 3 of 5)
[21:31:36] Winter weather: day 3 -> clear      (pattern position 4 of 5)
[21:31:37] Winter weather: day 4 -> clear      (pattern position 5 of 5)
[21:31:38] Winter weather: day 5 -> light_snow (pattern position 1 of 5)   ← 循环
```

## 4. 安装

`primalwinter-1.0.0+26.2-weathercycle.jar`（514 KB）放进 26.2 Fabric 实例的 `mods`。
**同一个 mod id（`primalwinter`）只能装一个**，换之前删掉旧的 `primalwinter-*.jar`。

需要：Minecraft 26.2 + Fabric Loader 0.19+ + Fabric API 0.161.0+26.2 + **Java 25**。

## 5. 改动文件（共 6 个）

| 文件 | 改动 |
|---|---|
| `platform/Config.java` | 新增 `enableSnowCycle`、`snowCyclePattern` 两个字段 |
| `platform/FabricConfig.java` | 注册这两个 TOML 项（默认 5 天模式） |
| `util/EventHandler.java` | 删除按秒计时器，改为「按天数取模式」；晴天下不再生成新积雪层 |
| `FabricPrimalWinter.java` | 注册 `ServerTickEvents.END_SERVER_TICK` |
| `FabricPrimalWinterClient.java` | 小雪 / 大雪的粒子数量与风声音量区分 |
| `mixin/client/WeatherEffectRendererMixin.java` | 小雪时雪柱半径缩到 55% |

其余（群系冬季化、世界生成、46 个方块、雾、染色、雨声屏蔽、日落光晕）与原移植版一致。

## 6. 自己编译

26.2 已去混淆，不需要 Loom：

```powershell
javac --release 25 -encoding UTF-8 -proc:none -cp <类路径> -d <输出目录> src\main\java\**\*.java
```

再把 `epsilon-0.6.jar` 的 class 解进输出目录，覆盖 `src\main\resources`，`jar --create` 打包。
注意：**输出目录要放在可写位置**（受限环境里 javac 子进程只能写工作区，直接写 `D:\qq` 会报 `could not create parent directories`）。

## 7. 已知事项

- 晴天雾仍在（雾按天空光照计算，不跟天气绑定，这是原模组逻辑）；想更清透把 `fogDensity` 调到 1.0。
- `/weather` 仍被禁用（与原模组一致），换天气请改配置里的模式表。
- 第 1 天从世界时间的 day 0 算起，跨天瞬间（time 0）切换状态。
